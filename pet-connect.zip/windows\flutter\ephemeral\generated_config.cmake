# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\abhis\\flutter\\flutter_windows_3.41.1-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\abhis\\StudioProjects\\pet-connect" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\abhis\\flutter\\flutter_windows_3.41.1-stable\\flutter"
  "PROJECT_DIR=C:\\Users\\abhis\\StudioProjects\\pet-connect"
  "FLUTTER_ROOT=C:\\Users\\abhis\\flutter\\flutter_windows_3.41.1-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\abhis\\StudioProjects\\pet-connect\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\abhis\\StudioProjects\\pet-connect"
  "FLUTTER_TARGET=C:\\Users\\abhis\\StudioProjects\\pet-connect\\lib\\main.dart"
  "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9WRVJTSU9OPTMuNDEuMQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049NTgyYTBlN2M1NQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MzQ1MmQ3MzViZA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4w"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\abhis\\StudioProjects\\pet-connect\\.dart_tool\\package_config.json"
)
